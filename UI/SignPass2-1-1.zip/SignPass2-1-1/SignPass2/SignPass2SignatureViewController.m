//
//  SignPass2SignatureViewController.m
//  SignPass2
//
//  Created by Jiankai Dang on 12/2/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import "SignPass2SignatureViewController.h"
#import "PaintingView.h"
#import "SignPass2MainViewController.h"
#import "SignPass2RecentsViewController.h"
#import "SignPass2SettingViewController.h"
#import "SignPass2AboutViewController.h"
//CONSTANTS:
#define kPaletteHeight			30
#define kPaletteSize			5
#define kMinEraseInterval		0.5

// Padding for margins
#define kLeftMargin				10.0
#define kTopMargin				10.0
#define kRightMargin			10.0
@interface SignPass2SignatureViewController ()

@end

@implementation SignPass2SignatureViewController
@synthesize drawingView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    CGFloat					components[3];
    
	// Defer to the OpenGL view to set the brush color
	[drawingView setBrushColorWithRed:components[0] green:components[1] blue:components[2]];
    [drawingView setBackgroundColor:[UIColor whiteColor]];
    
    CGRect frame = CGRectMake(5.0, 10.0, 30, 115);
    UIButton *button = [[UIButton alloc] initWithFrame:frame];
    
    button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    
    [button setTitle:@"HAha" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    UIImage *buttonBackground = [UIImage imageNamed:@"VB.png"];
    UIImage *buttonBackgroundPressed = [UIImage imageNamed:@"VBP.png"];
    
    UIImage *newImage = [buttonBackground stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0];
    [button setBackgroundImage:newImage forState:UIControlStateNormal];
    
    UIImage *newPressedImage = [buttonBackgroundPressed stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0];
    [button setBackgroundImage:newPressedImage forState:UIControlStateHighlighted];
    
    // in case the parent view draws with a custom color or gradient, use a transparent color
    button.backgroundColor = [UIColor clearColor];
    [button addTarget:self action:@selector(collectSignatureArray:)forControlEvents:UIControlEventTouchUpInside];
    
    
    CGRect frameErase = CGRectMake(5.0, 355.0, 30, 115);
    UIButton *buttonErase = [[UIButton alloc] initWithFrame:frameErase];
    
    buttonErase.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    buttonErase.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    
    [buttonErase setTitle:@"HAha" forState:UIControlStateNormal];
    [buttonErase setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    UIImage *buttonBackgroundErase = [UIImage imageNamed:@"EB.png"];
    UIImage *buttonBackgroundPressedErase = [UIImage imageNamed:@"EBP.png"];
    
    UIImage *newImageErase = [buttonBackgroundErase stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0];
    [buttonErase setBackgroundImage:newImageErase forState:UIControlStateNormal];
    
    UIImage *newPressedImageErase = [buttonBackgroundPressedErase stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0];
    [buttonErase setBackgroundImage:newPressedImageErase forState:UIControlStateHighlighted];
    
    // in case the parent view draws with a custom color or gradient, use a transparent color
    buttonErase.backgroundColor = [UIColor clearColor];
    [buttonErase addTarget:self action:@selector(eraseView:)forControlEvents:UIControlEventTouchUpInside];
    [button addTarget:self action:@selector(ButtonVerification:)forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:button];
    [self.view addSubview:buttonErase];
    [self.view addSubview:buttonErase];
    [self.view setBackgroundColor:[UIColor blackColor]];
    //    //[myButton addTarget:self action:@selector(goBackButtonClicked:)forControlEvents:UIControlEventTouchUpInside];
    // Look in the Info.plist file and you'll see the status bar is hidden
	// Set the style to black so it matches the background of the application
    UIApplication *application=[UIApplication sharedApplication];
	[application setStatusBarStyle:UIStatusBarStyleBlackTranslucent animated:NO];
	// Now show the status bar, but animate to the style.
	[application setStatusBarHidden:YES withAnimation:NO];
}
-(IBAction)ButtonVerification:(id)sender
{
    /*SignPass2MainViewController *nvc=[[SignPass2MainViewController alloc] initWithNibName:nil bundle:nil];
    [self presentModalViewController:nvc animated:YES];*/
    UITabBarController *TabBar=[[UITabBarController alloc]init];
    
    SignPass2RecentsViewController *RecentItem= [[SignPass2RecentsViewController alloc]init];
    SignPass2SettingViewController *SettingItem= [[SignPass2SettingViewController alloc]init];
    SignPass2AboutViewController *AboutItem= [[SignPass2AboutViewController alloc]init];
    /*[RecentItem.tabBarItem setTitle:@"Recent"];
     [SettingItem.tabBarItem setTitle:@"Setting"];
     [AboutItem.tabBarItem setTitle:@"About"];*/
    RecentItem.title=@"Recent";
    SettingItem.title=@"Setting";
    AboutItem.title=@"About";
    
    
    [TabBar setViewControllers:[NSArray arrayWithObjects:RecentItem,SettingItem,AboutItem, nil]];
    TabBar.selectedIndex=0;
    [UIApplication sharedApplication].keyWindow.rootViewController=TabBar;
}
- (void)collectSignatureArray:(id)sender
{
    //NSLog(@"Call collect signature Array");
	[drawingView collectSignatureArrayFromView];
}


-(void) eraseView:(id)sender
{
	[drawingView erase];
}
@end
