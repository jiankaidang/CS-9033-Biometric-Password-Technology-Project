//
//  SignPass2RegisterViewController.m
//  SignPass2
//
//  Created by Maneli Rabizadeh on 11/13/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import "SignPass2RegisterViewController.h"
#import "SignPass2SignatureViewController.h"

@interface SignPass2RegisterViewController ()

@end

@implementation SignPass2RegisterViewController

-(IBAction)Back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:NULL];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(IBAction)createSignature:(id)sender{
    SignPass2SignatureViewController *csp=[[SignPass2SignatureViewController alloc] initWithNibName:nil bundle:nil];
    [self presentModalViewController:csp animated:YES];
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    usernameText.keyboardType=UIKeyboardTypeAlphabet;
    emailText.keyboardType=UIKeyboardTypeEmailAddress;
    // Do any additional setup after loading the view from its nib.
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
-(IBAction)CheckUnique:(id)sender{
    int count=0;
    NSString *userCheckString=usernameText.text;
    const char *userCheckChar= [userCheckString cStringUsingEncoding:NSASCIIStringEncoding];
    if (userCheckChar[0]=='0' || userCheckChar[0]=='1' || userCheckChar[0]=='2' || userCheckChar[0]=='3' || userCheckChar[0]=='4' || userCheckChar[0]=='5' || userCheckChar[0]=='6' || userCheckChar[0]== '7' || userCheckChar[0]=='8' || userCheckChar[0]=='9')
    {
        
    checkLabel.text=@"*The username can not start with digit.";
        count++;
    }
    
    int usernameLength= userCheckString.length;
    
    for (int i=0; i< usernameLength; i++)
        if (userCheckChar[i]==' ')
        {
    
          checkLabel.text=@"*The username can not contain space.";
            count++;
        }
    if(count==0)
        checkLabel.text=@" ";
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
