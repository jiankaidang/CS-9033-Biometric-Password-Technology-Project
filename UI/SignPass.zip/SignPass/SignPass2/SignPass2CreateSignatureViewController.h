//
//  SignPass2CreateSignatureViewController.h
//  SignPass2
//
//  Created by Maneli Rabizadeh on 11/13/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignPass2CreateSignatureViewController : UIViewController

@end
