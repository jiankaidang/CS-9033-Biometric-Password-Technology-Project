//
//  SignPass2Tests.h
//  SignPass2Tests
//
//  Created by Maneli Rabizadeh on 10/18/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SignPass2Tests : SenTestCase

@end
