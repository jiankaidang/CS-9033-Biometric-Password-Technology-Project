//
//  SignPass2Tests.m
//  SignPass2Tests
//
//  Created by Maneli Rabizadeh on 10/18/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import "SignPass2Tests.h"

@implementation SignPass2Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SignPass2Tests");
}

@end
