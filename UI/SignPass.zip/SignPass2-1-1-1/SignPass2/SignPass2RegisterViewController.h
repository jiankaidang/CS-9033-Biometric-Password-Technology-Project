//
//  SignPass2RegisterViewController.h
//  SignPass2
//
//  Created by Maneli Rabizadeh on 11/13/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SignPass2CreateSignatureViewController.h"

@interface SignPass2RegisterViewController : UIViewController
{
    IBOutlet UILabel *username;
    IBOutlet UILabel *email;
    IBOutlet UILabel *checkLabel;
    IBOutlet UITextField *usernameText;
    IBOutlet UITextField *emailText;
    IBOutlet UIButton *createSignatureButton;
    
    
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
-(IBAction)Back:(id)sender;
-(IBAction)CheckUnique:(id)sender;
-(IBAction)createSignature:(id)sender;
-(void)presentModalViewController:(UIViewController *)modalViewController animated:(BOOL)animated;
-(void)dismissModalViewControllerAnimated:(BOOL)animated;
@end
