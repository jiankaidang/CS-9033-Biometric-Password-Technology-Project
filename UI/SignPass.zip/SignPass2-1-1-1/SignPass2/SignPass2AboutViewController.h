//
//  SignPass2AboutViewController.h
//  SignPass2
//
//  Created by Maneli Rabizadeh on 12/2/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignPass2AboutViewController : UIViewController

@end
