//
//  SignPass2AppDelegate.m
//  SignPass2
//
//  Created by Maneli Rabizadeh on 10/18/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import "SignPass2AppDelegate.h"

#import "SignPass2ViewController.h"
#import "SignPass2SignatureViewController.h"
@implementation SignPass2AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.viewController = [[SignPass2ViewController alloc] initWithNibName:@"SignPass2ViewController" bundle:nil];
    self.window.rootViewController = self.viewController;
    NSDictionary *payload=[launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    NSLog(@"%@",payload);
    if (payload) {
        [self application:application handlePushNotif:payload];
    }
    [self.window makeKeyAndVisible];
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound|UIRemoteNotificationTypeAlert)];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
// Delegation methods
- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)devToken {
    const char* data = [devToken bytes];
    NSMutableString* token = [NSMutableString string];
    
    for (int i = 0; i < [devToken length]; i++) {
        [token appendFormat:@"%02.2hhX", data[i]];
    }
    NSLog(@"%@",token);
    NSString *udid=[[[UIDevice currentDevice] identifierForVendor] UUIDString];
    self.devToken=token;
    self.udid=udid;
    NSMutableURLRequest *request= [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@signpass/ios/register_pushnotif?dev_token=%@&udid=%@",[[NSBundle mainBundle] objectForInfoDictionaryKey:@"BackEndServerIP"],token,udid]]];
    [request setHTTPMethod:@"GET"];
    [NSURLConnection connectionWithRequest:request delegate:self];
}

- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)err {
    NSLog(@"Error in registration. Error: %@", err);
}
-(void)application:(UIApplication *)app didReceiveRemoteNotification:(NSDictionary *)userInfo{
    self.payload=userInfo;
    app.applicationIconBadgeNumber = 0;
    [[[UIAlertView alloc] initWithTitle:@"SignPass" message:[NSString stringWithFormat:@"Login %@ with SignPass",[userInfo objectForKey:@"service_name"]] delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Sign", nil] show];
}
-(void)application:(UIApplication *)application handlePushNotif:(NSDictionary *)payload{
    NSLog(@"handlePushNotif");
    self.requestType=[payload objectForKey:@"requestType"];
    self.userName=[payload objectForKey:@"username"];
    self.serviceName=[payload objectForKey:@"service_name"];
    self.service_uid=[payload objectForKey:@"service_uid"];
    application.applicationIconBadgeNumber = 0;
    SignPass2SignatureViewController *csp=[[SignPass2SignatureViewController alloc] initWithNibName:nil bundle:nil];
    self.window.rootViewController=csp;
}
- (void)connection:(NSURLConnection *)theConnection didReceiveResponse:(NSURLResponse *)response
// A delegate method called by the NSURLConnection when the request/response
// exchange is complete.  We look at the response to check that the HTTP
// status code is 2xx.  If it isn't, we fail right now.
{
    NSHTTPURLResponse * httpResponse;
    httpResponse = (NSHTTPURLResponse *) response;
    assert( [httpResponse isKindOfClass:[NSHTTPURLResponse class]] );
    
    if ((httpResponse.statusCode / 100) != 2) {
        NSLog(@"HTTP error %zd", (ssize_t) httpResponse.statusCode);
    } else {
        NSLog(@"Response OK.");
    }
}

- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)data
// A delegate method called by the NSURLConnection as data arrives.  The
// response data for a POST is only for useful for debugging purposes,
// so we just drop it on the floor.
{
    NSLog(@"%@",[NSString stringWithUTF8String:data.bytes]);
}
- (void)connection:(NSURLConnection *)theConnection didFailWithError:(NSError *)error
// A delegate method called by the NSURLConnection if the connection fails.
// We shut down the connection and display the failure.  Production quality code
// would either display or log the actual error.
{
    
    NSLog(@"Connection failed");
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==1) {
        NSString *type=[self.payload objectForKey:@"requestType"];
        NSLog(@"requestType %@",type);
        self.requestType=[self.payload objectForKey:@"requestType"];
        self.userName=[self.payload objectForKey:@"username"];
        self.serviceName=[self.payload objectForKey:@"service_name"];
        self.service_uid=[self.payload objectForKey:@"service_uid"];
        SignPass2SignatureViewController *csp=[[SignPass2SignatureViewController alloc] initWithNibName:nil bundle:nil];
        self.window.rootViewController=csp;
    }
}
@end
