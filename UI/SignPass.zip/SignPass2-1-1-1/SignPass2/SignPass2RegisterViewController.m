//
//  SignPass2RegisterViewController.m
//  SignPass2
//
//  Created by Maneli Rabizadeh on 11/13/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import "SignPass2RegisterViewController.h"
#import "SignPass2SignatureViewController.h"
#import "SignPass2AppDelegate.h"
@interface SignPass2RegisterViewController ()
@property (weak, nonatomic) IBOutlet UILabel *emailCheckLabel;
@property int isCheckingUserName;
@end

@implementation SignPass2RegisterViewController

-(IBAction)Back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:NULL];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(IBAction)createSignature:(id)sender{
    self.isCheckingUserName=0;
    [self checkUserName];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    usernameText.keyboardType=UIKeyboardTypeAlphabet;
    emailText.keyboardType=UIKeyboardTypeEmailAddress;
    // Do any additional setup after loading the view from its nib.
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
-(IBAction)CheckUnique:(id)sender{
    self.isCheckingUserName=1;
    [self checkUserName];
    
}
-(void)checkUserName{
    NSError *error=NULL;
    NSString *userCheckString=usernameText.text;
    NSString *expression =@"^[A-Za-z][A-Za-z0-9_]{5,19}$";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:expression
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSTextCheckingResult *match =[regex firstMatchInString:userCheckString options:0 range:NSMakeRange(0,[userCheckString length])];
    if (match)
    {
        NSMutableURLRequest *request;
        NSURL *url= [NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.10.1:8000/signpass/ios/%@/check_username/",userCheckString]];
        request= [NSMutableURLRequest requestWithURL:url];
        [request setHTTPMethod:@"GET"];
        [NSURLConnection connectionWithRequest:request delegate:self];
        return;
    }
    checkLabel.textColor=[UIColor redColor];
    checkLabel.text=@"The username is not valid";
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)connection:(NSURLConnection *)theConnection didReceiveResponse:(NSURLResponse *)response
// A delegate method called by the NSURLConnection when the request/response
// exchange is complete.  We look at the response to check that the HTTP
// status code is 2xx.  If it isn't, we fail right now.
{
    NSHTTPURLResponse * httpResponse;
    httpResponse = (NSHTTPURLResponse *) response;
    assert( [httpResponse isKindOfClass:[NSHTTPURLResponse class]] );
    
    if ((httpResponse.statusCode / 100) != 2) {
        NSLog(@"HTTP error %zd", (ssize_t) httpResponse.statusCode);
    } else {
        NSLog(@"Response OK.");
    }
}

- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)data
// A delegate method called by the NSURLConnection as data arrives.  The
// response data for a POST is only for useful for debugging purposes,
// so we just drop it on the floor.
{
    NSLog(@"%@",[NSString stringWithUTF8String:data.bytes]);
    NSDictionary *response=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    if ([[response objectForKey:@"success"] boolValue]) {
        checkLabel.textColor=[UIColor greenColor];
        checkLabel.text=@"Username is Valid";
        NSLog(@"success");
        if (self.isCheckingUserName==0) {
            NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$" options:NSRegularExpressionCaseInsensitive
                                                                                     error:nil];
            NSTextCheckingResult *match =[regex firstMatchInString:emailText.text options:0 range:NSMakeRange(0,[emailText.text length])];
            if (match) {
                self.emailCheckLabel.hidden=true;
                SignPass2AppDelegate *delegate=[UIApplication sharedApplication].delegate;
                delegate.userName=usernameText.text;
                delegate.email=emailText.text;
                delegate.requestType=@"register";
                SignPass2SignatureViewController *csp=[[SignPass2SignatureViewController alloc] initWithNibName:nil bundle:nil];
                [self presentModalViewController:csp animated:YES];
                return;
            }
            self.emailCheckLabel.hidden=false;
        }
        return;
    }
    checkLabel.textColor=[UIColor redColor];
    checkLabel.text=@"The username is not valid";
    NSLog(@"%@",[response objectForKey:@"msg"]);
}
- (void)connection:(NSURLConnection *)theConnection didFailWithError:(NSError *)error
// A delegate method called by the NSURLConnection if the connection fails.
// We shut down the connection and display the failure.  Production quality code
// would either display or log the actual error.
{
    
    NSLog(@"Connection failed");
}
- (void)connectionDidFinishLoading:(NSURLConnection *)theConnection
// A delegate method called by the NSURLConnection when the connection has been
// done successfully.  We shut down the connection with a nil status, which
// causes the image to be displayed.
{
}

@end
