//
//  SignPass2SignatureViewController.m
//  SignPass2
//
//  Created by Jiankai Dang on 12/2/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import "SignPass2SignatureViewController.h"
#import "PaintingView.h"
#import "SignPass2MainViewController.h"
#import "SignPass2RecentsViewController.h"
#import "SignPass2SettingViewController.h"
#import "SignPass2AboutViewController.h"
#import "SignPass2AppDelegate.h"
#include <CommonCrypto/CommonDigest.h>
//CONSTANTS:
#define kPaletteHeight			30
#define kPaletteSize			5
#define kMinEraseInterval		0.5

// Padding for margins
#define kLeftMargin				10.0
#define kTopMargin				10.0
#define kRightMargin			10.0
@interface SignPass2SignatureViewController ()
@property NSString *signature;
@end

@implementation SignPass2SignatureViewController
@synthesize drawingView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    CGFloat					components[3];
    
	// Defer to the OpenGL view to set the brush color
	[drawingView setBrushColorWithRed:components[0] green:components[1] blue:components[2]];
    [drawingView setBackgroundColor:[UIColor whiteColor]];
    
    CGRect frame = CGRectMake(5.0, 10.0, 30, 115);
    UIButton *button = [[UIButton alloc] initWithFrame:frame];
    
    button.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    
    [button setTitle:@"HAha" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    UIImage *buttonBackground = [UIImage imageNamed:@"VB.png"];
    UIImage *buttonBackgroundPressed = [UIImage imageNamed:@"VBP.png"];
    
    UIImage *newImage = [buttonBackground stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0];
    [button setBackgroundImage:newImage forState:UIControlStateNormal];
    
    UIImage *newPressedImage = [buttonBackgroundPressed stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0];
    [button setBackgroundImage:newPressedImage forState:UIControlStateHighlighted];
    
    // in case the parent view draws with a custom color or gradient, use a transparent color
    button.backgroundColor = [UIColor clearColor];
    [button addTarget:self action:@selector(collectSignatureArray:)forControlEvents:UIControlEventTouchUpInside];
    
    
    CGRect frameErase = CGRectMake(5.0, 355.0, 30, 115);
    UIButton *buttonErase = [[UIButton alloc] initWithFrame:frameErase];
    
    buttonErase.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    buttonErase.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    
    [buttonErase setTitle:@"HAha" forState:UIControlStateNormal];
    [buttonErase setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    UIImage *buttonBackgroundErase = [UIImage imageNamed:@"EB.png"];
    UIImage *buttonBackgroundPressedErase = [UIImage imageNamed:@"EBP.png"];
    
    UIImage *newImageErase = [buttonBackgroundErase stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0];
    [buttonErase setBackgroundImage:newImageErase forState:UIControlStateNormal];
    
    UIImage *newPressedImageErase = [buttonBackgroundPressedErase stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0];
    [buttonErase setBackgroundImage:newPressedImageErase forState:UIControlStateHighlighted];
    
    // in case the parent view draws with a custom color or gradient, use a transparent color
    buttonErase.backgroundColor = [UIColor clearColor];
    [buttonErase addTarget:self action:@selector(eraseView:)forControlEvents:UIControlEventTouchUpInside];
    [button addTarget:self action:@selector(ButtonVerification:)forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:button];
    [self.view addSubview:buttonErase];
    [self.view addSubview:buttonErase];
    [self.view setBackgroundColor:[UIColor blackColor]];
    //    //[myButton addTarget:self action:@selector(goBackButtonClicked:)forControlEvents:UIControlEventTouchUpInside];
    // Look in the Info.plist file and you'll see the status bar is hidden
	// Set the style to black so it matches the background of the application
    UIApplication *application=[UIApplication sharedApplication];
	[application setStatusBarStyle:UIStatusBarStyleBlackTranslucent animated:NO];
	// Now show the status bar, but animate to the style.
	[application setStatusBarHidden:YES withAnimation:NO];
}
-(IBAction)ButtonVerification:(id)sender
{
    SignPass2AppDelegate *appDelegate=[UIApplication sharedApplication].delegate;
    NSMutableString * sUrl=[NSMutableString stringWithCapacity:256];
    [sUrl appendString:@"http://192.168.10.1:8000/signpass/ios/"];
    NSString *signature=CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(
                                                                NULL,
                                                                (CFStringRef)self.signature,
                                                                NULL,
                                                                (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                kCFStringEncodingUTF8 ));
    if (appDelegate.requestType==@"register") {
        [sUrl appendFormat:@"register?username=%@&email=%@&signature=%@",appDelegate.userName,appDelegate.email,signature];
    }else if (appDelegate.requestType==@"verify"){
        [sUrl appendFormat:@"verify?username=%@&signature=%@",appDelegate.userName,signature];
    }else if (appDelegate.requestType==@"modify"){
        [sUrl appendFormat:@"modify?username=%@&signature=%@",appDelegate.userName,signature];
    }
    NSMutableURLRequest *request;
    NSURL *url= [NSURL URLWithString:sUrl];
    request= [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"GET"];
    NSLog(@"%@",url);
    [NSURLConnection connectionWithRequest:request delegate:self];
}
- (void)collectSignatureArray:(id)sender
{
    //NSLog(@"Call collect signature Array");
	self.signature=[self createSHA512:[drawingView collectSignatureArrayFromView]];
}


-(void) eraseView:(id)sender
{
	[drawingView erase];
}
-(NSString *) createSHA512:(NSString *)source {
    
    const char *s = [source cStringUsingEncoding:NSASCIIStringEncoding];
    
    NSData *keyData = [NSData dataWithBytes:s length:strlen(s)];
    
    uint8_t digest[64] = {0};
    
    CC_SHA512(keyData.bytes, keyData.length, digest);
    
    NSData *out = [NSData dataWithBytes:digest length:64];
    
    return [out description];
}
- (void)connection:(NSURLConnection *)theConnection didReceiveResponse:(NSURLResponse *)response
// A delegate method called by the NSURLConnection when the request/response
// exchange is complete.  We look at the response to check that the HTTP
// status code is 2xx.  If it isn't, we fail right now.
{
    NSHTTPURLResponse * httpResponse;
    httpResponse = (NSHTTPURLResponse *) response;
    assert( [httpResponse isKindOfClass:[NSHTTPURLResponse class]] );
    
    if ((httpResponse.statusCode / 100) != 2) {
        NSLog(@"HTTP error %zd", (ssize_t) httpResponse.statusCode);
    } else {
        NSLog(@"Response OK.");
    }
}

- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)data
// A delegate method called by the NSURLConnection as data arrives.  The
// response data for a POST is only for useful for debugging purposes,
// so we just drop it on the floor.
{
    NSLog(@"%@",[NSString stringWithUTF8String:data.bytes]);
    NSDictionary *response=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    if ([[response objectForKey:@"success"] boolValue]) {
        /*SignPass2MainViewController *nvc=[[SignPass2MainViewController alloc] initWithNibName:nil bundle:nil];
         [self presentModalViewController:nvc animated:YES];*/
        UITabBarController *TabBar=[[UITabBarController alloc]init];
        
        SignPass2RecentsViewController *RecentItem= [[SignPass2RecentsViewController alloc]init];
        SignPass2SettingViewController *SettingItem= [[SignPass2SettingViewController alloc]init];
        SignPass2AboutViewController *AboutItem= [[SignPass2AboutViewController alloc]init];
        /*[RecentItem.tabBarItem setTitle:@"Recent"];
         [SettingItem.tabBarItem setTitle:@"Setting"];
         [AboutItem.tabBarItem setTitle:@"About"];*/
        RecentItem.title=@"Recent";
        SettingItem.title=@"Setting";
        AboutItem.title=@"About";
        
        
        [TabBar setViewControllers:[NSArray arrayWithObjects:RecentItem,SettingItem,AboutItem, nil]];
        SignPass2AppDelegate *appDelegate=[UIApplication sharedApplication].delegate;
        if (appDelegate.requestType==@"modify") {
            TabBar.selectedIndex=1;
        }
        TabBar.selectedIndex=0;
        [UIApplication sharedApplication].keyWindow.rootViewController=TabBar;
        return;
    }
    NSLog(@"%@",[response objectForKey:@"msg"]);
}
- (void)connection:(NSURLConnection *)theConnection didFailWithError:(NSError *)error
// A delegate method called by the NSURLConnection if the connection fails.
// We shut down the connection and display the failure.  Production quality code
// would either display or log the actual error.
{
    
    NSLog(@"Connection failed");
}
@end
