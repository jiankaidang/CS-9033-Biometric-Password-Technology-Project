//
//  SignPass2AppDelegate.h
//  SignPass2
//
//  Created by Maneli Rabizadeh on 10/18/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SignPass2ViewController;

@interface SignPass2AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) SignPass2ViewController *viewController;
@property (nonatomic)NSString *userName;
@property (nonatomic)NSString *email;
@property (nonatomic)NSString *requestType;
@end
