//
//  SignPass2SettingViewController.m
//  SignPass2
//
//  Created by Maneli Rabizadeh on 12/3/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import "SignPass2SettingViewController.h"
#import "SignPass2AboutViewController.h"
#import "SignPass2RecentsViewController.h"
#import "SignPass2SignatureViewController.h"
#import "SignPass2AppDelegate.h"
@interface SignPass2SettingViewController ()
- (IBAction)modifySignature;

@end

@implementation SignPass2SettingViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)NavToAboutView:(id)sender{
    SignPass2AboutViewController *AboutView=[[SignPass2AboutViewController alloc] initWithNibName:nil bundle:nil];
    [self presentModalViewController:AboutView animated:YES];
    
    UITabBarController *TabBar=[[UITabBarController alloc]init];
    
    SignPass2RecentsViewController *RecentItem= [[SignPass2RecentsViewController alloc]init];
    SignPass2SettingViewController *SettingItem= [[SignPass2SettingViewController alloc]init];
    SignPass2AboutViewController *AboutItem= [[SignPass2AboutViewController alloc]init];
    /*[RecentItem.tabBarItem setTitle:@"Recent"];
     [SettingItem.tabBarItem setTitle:@"Setting"];
     [AboutItem.tabBarItem setTitle:@"About"];*/
    RecentItem.title=@"Recent";
    SettingItem.title=@"Setting";
    AboutItem.title=@"About";
    
    
    [TabBar setViewControllers:[NSArray arrayWithObjects:RecentItem,SettingItem,AboutItem, nil]];
    TabBar.selectedIndex=2;
    [UIApplication sharedApplication].keyWindow.rootViewController=TabBar;}
- (IBAction)modifySignature {
    SignPass2AppDelegate *delegate=[UIApplication sharedApplication].delegate;
    delegate.requestType=@"modify";
    SignPass2SignatureViewController *csp=[[SignPass2SignatureViewController alloc] initWithNibName:nil bundle:nil];
    [UIApplication sharedApplication].keyWindow.rootViewController=csp;
}
@end
