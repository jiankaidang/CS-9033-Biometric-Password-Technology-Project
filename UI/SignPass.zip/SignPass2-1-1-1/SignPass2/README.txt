Read Me About SignPass
=============================
SignPass requires iOS 5.1 or later

Building the App
-------------------
The app was built using Xcode 4.5.2 on Mac OS X 10.7.5 with iOS 6.0 SDK.  You should be able to just open the project and choose Build from the Build menu.  The resulting program should be compatible with all devices running iOS 5.1 and later.  The bulk of my testing was done with an iPad 2 running iOS 6.0.

Because SignPass has the feature of Push Notification, we need to run it in the iPhone devices, set the Active SDK to your iPhone.
Credits
---------------------------
Instructor: Professor Nasir Memon
            Professor Massimiliano Pala

Team: 
Jiankai Dang
Maneli Kadkhodazadeh
Changepeng Li
Jerome Yang Li

If you find any problems with this app, please file a bug against it.

Share and Enjoy.