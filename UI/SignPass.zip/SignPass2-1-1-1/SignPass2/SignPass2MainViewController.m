//
//  SignPass2MainViewController.m
//  SignPass2
//
//  Created by Maneli Rabizadeh on 12/2/12.
//  Copyright (c) 2012 Maneli Kadkhodazadeh. All rights reserved.
//

#import "SignPass2MainViewController.h"
#import "SignPass2RecentsViewController.h"
#import "SignPass2SettingViewController.h"
#import "SignPass2AboutViewController.h"

@interface SignPass2MainViewController ()

@end

@implementation SignPass2MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UITabBarController *TabBar=[[UITabBarController alloc]init];
    
    SignPass2RecentsViewController *RecentItem= [[SignPass2RecentsViewController alloc]init];
    SignPass2SettingViewController *SettingItem= [[SignPass2SettingViewController alloc]init];
    SignPass2AboutViewController *AboutItem= [[SignPass2AboutViewController alloc]init];
    /*[RecentItem.tabBarItem setTitle:@"Recent"];
    [SettingItem.tabBarItem setTitle:@"Setting"];
    [AboutItem.tabBarItem setTitle:@"About"];*/
    RecentItem.title=@"Recent";
    SettingItem.title=@"Setting";
    AboutItem.title=@"About";

    
    [TabBar setViewControllers:[NSArray arrayWithObjects:RecentItem,SettingItem,AboutItem, nil]];
    TabBar.selectedIndex=0;
    [UIApplication sharedApplication].keyWindow.rootViewController=TabBar;
    //[self.view addSubview:TabBar.view];
    
    
    
     
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
