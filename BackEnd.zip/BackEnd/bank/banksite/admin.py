__author__ = 'Jiankai Dang'
from banksite.models import User
from django.contrib import admin

admin.site.register(User)